# Experiment Assignment Service

A small Go service for deterministic experiment assignment, durable exposure/conversion tracking, atomic experiment configuration, and descriptive results reporting.

**Status:** Assignment path and API, PostgreSQL integration code, HTTP tracking/results endpoints, migrations, and tests are implemented. The PostgreSQL integration tests are supplied but **have not been executed in this environment** because it lacks a PostgreSQL instance and outbound Go dependency access. No external deployment or GitHub repository has been created here. Treat this as an implementation candidate until those checks are completed.

## Architecture at a glance

- Stateless assignment (SHA-256, 10,000 integer buckets); no per-visitor assignment rows.
- Immutable cohort identity and variant allocations; monotonic enrollment ramp-up, pause/resume, revision checks.
- PostgreSQL stores append-only configuration snapshots and the active revision pointer; transactional compare-and-swap publishing.
- PostgreSQL `exposures` and `conversions` tables enforce both event-ID and semantic uniqueness.
- Results API counts distinct exposed/converting visitors per cohort and goal; no statistical winner is claimed.
- Browser adapter demonstrates a short assignment deadline, default rendering fallback, and nonblocking exposure tracking.

See [DESIGN.md](docs/DESIGN.md), [ADR-001](docs/ADR-001-core-invariants.md), and [ADR-002](docs/ADR-002-control-plane-and-events.md).

## Requirements

- Docker and Docker Compose for the recommended full run. Container build needs internet access to fetch Go modules.
- Or Go 1.23+ and an accessible PostgreSQL 16+ instance for direct execution.
- Without a DB or network, the assignment-only file-mode server and its dependency-free tests still run.

## Recommended: run full service with Docker Compose

```bash
cp .env.example .env
# Edit POSTGRES_PASSWORD and ADMIN_TOKEN in .env to strong, unique values.
docker compose up --build -d
docker compose ps
curl -fsS http://localhost:8080/healthz
curl -fsS http://localhost:8080/readyz
```

On first startup, the `config/experiments.json` document seeds an empty DB. Subsequent startups load the durable last-published configuration instead of overwriting it. PostgreSQL data persists in the Compose volume.

**Important:** The default `.env.example` values are placeholders, not real secrets; change both before deployment. The Compose database connection uses internal plaintext `sslmode=disable` for local container networking only. For managed PostgreSQL, configure TLS.

## Direct Go execution

**Assignment-only mode**, no DB required:

```bash
go run ./cmd/api
# Alternative port: PORT=18083 go run ./cmd/api
```

**PostgreSQL mode** uses a build tag to opt into the pgx driver:

```bash
# Start your PostgreSQL instance, then set variables with actual values:
export DATABASE_URL='postgres://experiment:YOUR_PASSWORD@localhost:5432/experiments?sslmode=disable'
export ADMIN_TOKEN='REPLACE_WITH_LONG_RANDOM_ADMIN_TOKEN'
export CONFIG_PATH='config/experiments.json'
go mod tidy
go run -tags pgx ./cmd/api
```

This requires network access on first pgx dependency download. In this environment, only the no-DB build can be executed. In database mode the application creates the initial tables at startup for this exercise; a separate migration job is recommended for production.

## API throttling and browser retry behavior

The Go API applies dependency-free token-bucket limits **per TCP peer** and per
**process**. Assignment requests, tracking writes (exposures + conversions share
one budget), and admin requests have separate budgets. Defaults per instance:

| Route group | Peer requests/sec | Peer burst | Aggregate ceiling |
| --- | ---: | ---: | ---: |
| Assignments | 1500 | 3000 | 10× per-peer limit |
| Tracking | 60 | 120 | 10× per-peer limit |
| Admin | 10 | 20 | 10× per-peer limit |

A rejected request returns **429** with `Retry-After: 1` and
`{"error":"rate_limited"}`. Customize via `ASSIGN_RATE_RPS`,
`ASSIGN_RATE_BURST`, `TRACK_RATE_RPS`, `TRACK_RATE_BURST`,
`ADMIN_RATE_RPS`, and `ADMIN_RATE_BURST` in `.env` and Docker Compose.
All values must be positive integers. Throttling is in-memory, so it resets
on restart and is not coordinated across replicas.

**Proxy caveat:** The limiter deliberately ignores `X-Forwarded-For` from
untrusted callers. Behind a reverse proxy it sees the proxy IP, so several
clients may share a bucket. Configure trusted hosting-edge rate limits and
project quotas for genuine client-IP handling and distributed abuse defense.
The public project key is not a secret; rate limiting cannot prevent all event
forgery or targeted quota exhaustion.

`examples/browser-integration.js` treats an assignment 429 as a fail-safe
control render. It retries **tracking only** on network/time-out errors and
HTTP **429, 502, 503, or 504**, up to **3 attempts**, reusing the **identical
JSON payload and event_id**. It does not retry permanent 4xx or block page
rendering. Custom `onExposure` callbacks own their retry policy. Conversion
calls return their final HTTP response: check `.ok`, and handle `409
exposure_not_found` after exposure persistence. This is **best-effort** delivery:
close/reload, extended offline periods, or browser lifecycle limits can lose
events; no durable local queue is implemented.

JavaScript tests (Node 22+):

```bash
node --test examples/browser-integration.test.mjs
```

## APIs

### Assign multiple experiments

```bash
curl -sS -X POST http://localhost:8080/v1/assignments \
  -H 'Content-Type: application/json' \
  -d '{"project_key":"pk_demo","visitor_id":"visitor-123","experiment_keys":["checkout_button_v1","homepage_layout_v1"]}'
```

The response includes per-experiment statuses: `assigned`, `not_enrolled`, `inactive`, or `unknown_experiment`. An assigned result contains `variant_key` and immutable `assignment_id`.

### Record exposure

Only emit this **after the assigned variant is actually visible**. Copy `assignment_id` and `variant_key` from a successful assignment response; use a unique event ID and the current UTC timestamp.

```bash
curl -i -X POST http://localhost:8080/v1/events/exposure \
  -H 'Content-Type: application/json' \
  -d '{"event_id":"274b4ee7-e2f2-4a08-9846-cd8ae4c0cdb2","project_key":"pk_demo","experiment_key":"checkout_button_v1","assignment_id":"cohort-checkout-button-001","visitor_id":"visitor-123","variant_key":"REPLACE_WITH_ASSIGNED_VARIANT","occurred_at":"REPLACE_WITH_CURRENT_RFC3339_UTC_TIME"}'
```

`201` indicates newly recorded; `200` indicates a duplicate that was already counted. The server recomputes the canonical variant; a mismatch is rejected. Avoid reusing the event ID with a different payload.

### Record a conversion

```bash
curl -i -X POST http://localhost:8080/v1/events/conversion \
  -H 'Content-Type: application/json' \
  -d '{"event_id":"323a5d6c-a791-44a0-8c2b-3caaf5b72791","project_key":"pk_demo","experiment_key":"checkout_button_v1","assignment_id":"cohort-checkout-button-001","visitor_id":"visitor-123","goal":"checkout_completed","occurred_at":"REPLACE_WITH_CURRENT_RFC3339_UTC_TIME"}'
```

A conversion requires an existing exposure and may be counted once per exposure/goal. `409 exposure_not_found` means retry after the exposure has committed. An accepted event is only acknowledged after a PostgreSQL commit.

### Read or publish a configuration

**Admin endpoints require the `Authorization: Bearer $ADMIN_TOKEN` header.** Never use this token in browser JavaScript.

```bash
curl -sS http://localhost:8080/v1/admin/config \
  -H "Authorization: Bearer ${ADMIN_TOKEN}"
```

The publish endpoint accepts the **complete** document, plus an expected global revision. Use a file such as `publish.json`:

```json
{
  "expected_revision": 1,
  "configuration": {
    "projects": [
      {
        "id": "demo-project-001",
        "public_key": "pk_demo",
        "experiments": [
          {
            "key": "checkout_button_v1",
            "assignment_id": "cohort-checkout-button-001",
            "revision": 2,
            "status": "paused",
            "traffic_bps": 8000,
            "variants": [
              {"key": "control", "weight_bps": 5000},
              {"key": "treatment", "weight_bps": 5000}
            ]
          },
          {
            "key": "homepage_layout_v1",
            "assignment_id": "cohort-homepage-layout-001",
            "revision": 1,
            "status": "active",
            "traffic_bps": 10000,
            "variants": [
              {"key": "control", "weight_bps": 5000},
              {"key": "compact", "weight_bps": 3000},
              {"key": "expanded", "weight_bps": 2000}
            ]
          }
        ]
      }
    ]
  }
}
```

```bash
curl -i -X POST http://localhost:8080/v1/admin/config \
  -H "Authorization: Bearer ${ADMIN_TOKEN}" \
  -H 'Content-Type: application/json' \
  --data-binary @publish.json
```

The example pauses `checkout_button_v1`. It assumes the initial revision is 1; GET the current revision first if another publication has occurred. A stale `expected_revision` returns 409. Removing previously published experiments, reducing their traffic allocation, or mutating variant weights/ordering is rejected. Creating a new cohort requires a distinct experiment key and `assignment_id`.

### Results

```bash
curl -sS 'http://localhost:8080/v1/admin/results?project_key=pk_demo&experiment_key=checkout_button_v1&goal=checkout_completed' \
  -H "Authorization: Bearer ${ADMIN_TOKEN}"
```

Returns all canonical variants, including zero-exposure variants (whose rate is `null`), with unique exposures, conversions, and conversion rates. Results are descriptive, not a formal significance verdict.

## Tests

```bash
go test ./...
go test -race ./...
go vet ./...
```

Optional actual-database integration tests, with an accessible PostgreSQL instance and Go module downloads:

```bash
export TEST_DATABASE_URL='postgres://experiment:YOUR_PASSWORD@localhost:5432/experiments?sslmode=disable'
go mod tidy
go test -tags pgx ./internal/storage -run Integration -v
```

The integration test creates an isolated temporary PostgreSQL schema and drops it afterward. It checks published snapshots, stale revision conflicts, immutable allocations, event retries, conversions, and SQL results. The included in-memory fake-repository tests do not replace a live DB test.

## Failure and correctness boundaries

- Warm assignment requests do not query or write to PostgreSQL. Refreshers poll for new snapshots every two seconds; a DB outage leaves the last valid in-process snapshot in memory.
- A cold process cannot boot in DB mode without database access. A pause/kill-switch publication may be delayed while cached configurations remain active.
- Tracking storage failure yields 503; no false durable success. Browser close or persistent network outage can still lose events.
- A conversion arriving before its exposure receives a retryable 409. Pending-event reconciliation is deferred.
- Event `occurred_at` is restricted to roughly the last seven days and at most five minutes in the future; this is an MVP validation policy, not configurable attribution windows.
- Public project IDs do not authenticate callers. Browser events can be fabricated; signed assignment receipts, abuse prevention, visitor identity rules, tenant RBAC, operational metrics, and retention policies are future work.
- No external deployment or public GitHub link is included in this archive; complete them before submission.
